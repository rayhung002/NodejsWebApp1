
class Button extends React.Component {
    render() {
        return <button>test button</button>
    }
}
export default Button;